#include <stdio.h>
#include <stdlib.h>

// Função para ler números de um arquivo e armazená-los em um vetor
int *lerNumerosDoArquivo(const char *nomeArquivo, int *tamanho) {
    FILE *arquivo = fopen(nomeArquivo, "r");

    if (arquivo == NULL) {
        perror("Erro ao abrir o arquivo");
        return NULL;
    }

    int capacidade = 10;
    int *vetor = (int *)malloc(capacidade * sizeof(int));

    if (vetor == NULL) {
        perror("Erro na alocação de memória");
        fclose(arquivo);
        return NULL;
    }

    int numero;
    *tamanho = 0;

    while (fscanf(arquivo, "%d", &numero) == 1) {
        if (*tamanho == capacidade) {
            capacidade *= 2;
            vetor = (int *)realloc(vetor, capacidade * sizeof(int));

            if (vetor == NULL) {
                perror("Erro na realocação de memória");
                fclose(arquivo);
                return NULL;
            }
        }

        vetor[*tamanho] = numero;
        (*tamanho)++;
    }

    fclose(arquivo);
    return vetor;
}

// Função para imprimir os números armazenados no vetor
void imprimirNumeros(const int *vetor, int tamanho) {
    printf("Os números lidos do arquivo são:\n");
    for (int i = 0; i < tamanho; i++) {
        printf("%d ", vetor[i]);
    }
    printf("\n");
}

int main() {
    int tamanho;
    int *vetor = lerNumerosDoArquivo("numeros.txt", &tamanho);

    if (vetor == NULL) {
        return 1;
    }

    imprimirNumeros(vetor, tamanho);

    free(vetor);

    return 0;
}
